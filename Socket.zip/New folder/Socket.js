var data;
var data2;
const Http = new XMLHttpRequest();
const url='https://api.coindesk.com/v1/bpi/currentprice.json';
Http.open("GET", url);
Http.send();

Http.onreadystatechange = (e) => {
  data=Http.responseText;
}

function BitcoinPrice(){
var dataA=data.split(" ");    
var dataB= dataA[29].toString();
var dataC=dataB.split(":{");
var dataD=dataC[2].toString();
var dataE=dataD.substring(38);
var dataF=dataE.substring(0,dataE.length-25);
document.getElementById('BPrice').value=dataF;
}

const Http2 = new XMLHttpRequest();
const url2='https://worldtimeapi.org/api/timezone/America/New_York';
Http2.open("GET", url2);
Http2.send();

Http2.onreadystatechange = (e) => {
  data2=Http2.responseText;
}

function datatime(){
var y1= data2.split(":");
var y2= y1[3].split("-");
var month= y2[1];
document.getElementById('Month').value=month;
var year=y2[0].substring(1);
document.getElementById('Year').value=year;
var day =y2[2].substring(0,2);
document.getElementById('Day').value=day;

}
